rm -f $XORG_PREFIX/lib/pkgconfig/xcb-proto.pc
